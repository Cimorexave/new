<?php

$host = "localhost";
$user = "root";
$password = "";
$db_name = "schule_db";
