<?php

$host = "localhost";
$user = "root";
$password = "";
$db_name = "ueberweisungen_db";
